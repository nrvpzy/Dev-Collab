package com.nrv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoreServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
